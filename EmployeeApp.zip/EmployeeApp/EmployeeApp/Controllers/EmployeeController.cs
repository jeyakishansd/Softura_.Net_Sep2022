﻿using EmployeeApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeApp.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult AllEmployeeDetails()
        {
            List<Employee> employee = Employee.GetAllEmployees();
            return View(employee);
        }
        public IActionResult EmpDetails()
        {
            Employee emp = Employee.EmpDetails();
            return View(emp);
        }
        public IActionResult NewEmployee()
        {
            return View();
        }
    }
}
