﻿namespace EmployeeApp.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string FirstName{ get; set; }
        public string LastName{ get; set; }
        public string Gender { get; set; }

        public static Employee EmpDetails()
        {
            Employee empDetails = new Employee()
            {
                EmployeeId = 6,
                FirstName = "Kokki",
                LastName = "Kumar",
                Gender = "Male"
            };
            return empDetails;
        }
        public static List<Employee> GetAllEmployees()
        {
            List<Employee> Employee = new(){
           new Employee(){EmployeeId=1,FirstName="Jey",LastName="Kee",Gender="Male" },
           new Employee(){EmployeeId=2,FirstName="Ajay",LastName="Rayen",Gender="Male"},
           new Employee(){EmployeeId=3,FirstName="Siva",LastName="Priya",Gender="Female"},
           new Employee(){EmployeeId=4,FirstName="Samuel",LastName="Ravichandran",Gender="Male"},
           new Employee(){EmployeeId=5,FirstName="Swetha",LastName="Kumar",Gender="Female"}
        };
            return Employee;
        }

    }
}
